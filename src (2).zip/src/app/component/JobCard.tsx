//@ts-nocheck
export default function JobCard({ job }) {
  return (
    <div className="p-4 border rounded-xl h-[400px] overflow-hidden shadow-md hover:shadow-lg transition">
      {/* {job.employer_logo && (
        <img
          src={job.employer_logo}
          alt={job.employer_name}
          className="w-16 h-16  mb-3"
        />
      )} */}
      <h2 className="text-lg font-bold mb-1">{job.title}</h2>
      <p className="text-sm text-gray-500 mb-2">{job.salary}</p>
      <p className="text-sm text-gray-600 mb-1">{job.description}</p>
      <p className="text-sm text-gray-500 mb-2">{job.location}</p>

     
    </div>
  );
}
