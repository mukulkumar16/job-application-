'use client'

import { useState } from "react";
import Addjob from "./Addjob";


export function Header() {
  const [q, setQ] = useState("");
  // const router = useRouter();

  // function handleSearch(e) {
  //   e.preventDefault();
  //   if (q.trim()) {
  //     router.push(`/search?query=${q.trim()}`);
  //   }
  // }
  return (

    <header>
      <div className="h-[100px] p-9 w-[100vw] bg-emerald-700 flex  justify-between">
        <div className="font-bold text-amber-50">
          Jobs Dekhoo
        </div>
        <form action={'/search'} method="GET" className="flex gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search jobs"
            name="q"
            className="border px-3 py-2 rounded w-full"
          />
          <button type="submit" className="px-4 bg-green-600 text-white rounded">Search</button>
        </form>
        <Addjob/>
      
      </div>
    </header>

  )
}