//@ts-nocheck
import { Theme } from "@radix-ui/themes";

export default function ThemeContext({children}){
    return (
        <div>
            <Theme >

            {children}
            </Theme>
        </div>
    )
}