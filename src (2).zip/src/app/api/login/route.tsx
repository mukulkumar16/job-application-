//@ts-nocheck
import prismaclient from "@/services/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
    const body = await req.json();
    console.log(body.email);

    const user = await prismaclient.user.findUnique({
        where: {
            email: body.email
        }
    })

    // console.log("user password " , user?.password);
    // console.log("body password " , body.password);


    if (user.password === body?.password) {
        const res = NextResponse.json({
            success: true,
            user,
        });
        res.cookies.set("token", user.email);
        return res;

        // return NextResponse.json({
        //     success : true,
        //     user
        // })
       
    }
    else{
        return NextResponse.json({
        success: false,
        message : "responce nhi jaa rha h "
    })
    }
    
}