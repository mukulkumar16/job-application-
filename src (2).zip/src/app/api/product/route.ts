import prismaclient from "@/services/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req : NextRequest){
    const body = await req.json();
    console.log(body.title);
    const prodToStore = {
         title: body.title,
            description: body.description,
            location: body.job_location,
            salary: body.salary,
            // employment_type: body.emp_type,
            job_type: body.job_type
      
    }

    console.log(prodToStore);
    const product = await prismaclient.job.create({
        data : prodToStore
    })

    if(!product){
        return {
            success : false,
            message : "not added"
        }
    }

    return NextResponse.json({
        success : true,
        data : product
        
    })

}