//@ts-nocheck
import prismaclient from "@/services/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req : NextRequest){
    const searchParams = req.nextUrl.searchParams;
    const q = searchParams.get('q');
    console.log(q);
    const mn = searchParams.get('min') ? Number.parseInt(searchParams.get('min')) : 0 ;
    const mx = searchParams.get('max') ? Number.parseInt(searchParams.get('max')) : 100000 ;
    const jobtype = searchParams.get('jobType');

    try{

        const jobs = await prismaclient.job.findMany({
            where : {
                title : {
                    contains : q , 
                    mode : "insensitive"
                },
                salary : {
                    gte : mn,
                    lte : mx
                },
                job_type : jobtype
        
                 
            }
    
        })
    
        return NextResponse.json({
            success : true,
            data : jobs
        })
    }catch(error){
        console.error(error);
        

    }
}