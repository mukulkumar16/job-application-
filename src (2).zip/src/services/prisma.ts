import { PrismaClient } from "../../generated/prisma";

const prismaclient = new PrismaClient();

export default prismaclient;


